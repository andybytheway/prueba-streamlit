import streamlit as st

pages = {
    "Datos y visualizacion": [
        st.Page("Indicadores.py", title="Indicadores de calidad de vida"),
        st.Page("Tabla.py", title="Tablad de datos"),
    ],
    "Graficas": [
        st.Page("graficaBarras.py", title="Grafica de barras"),
        st.Page("Histograma.py", title="Histograma"),
        st.Page("GraficaCaja.py", title="Grafica de caja"),
        st.Page("GraficaDispersion.py", title="Grafica de Dispersion"),
    ],
}

pg = st.navigation(pages)
pg.run()