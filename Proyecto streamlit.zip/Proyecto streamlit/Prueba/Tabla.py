import streamlit as st
import pandas as pd

###################################
# Tabla de datos
##################################

st.subheader("Tabla de datos")
st.write("Los datos que exploraremos están disponibles en la siguiente tabla:")

df = pd.read_csv("../Datos/quality_life_2020.csv", sep=";")
st.dataframe(df)

col1, col2, col3 = st.columns([1,2,1])  # Más espacio a la izquierda
with col3:
    st.page_link("GraficaBarras.py", label="Pagina siguiente", icon="🔜")
with col1:
    st.page_link("Indicadores.py", label="Pagina anterior", icon="🔙")
