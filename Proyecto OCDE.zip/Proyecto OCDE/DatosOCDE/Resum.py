import streamlit as st
import pandas as pd

# Cargar datos directamente en esta página
@st.cache_data
def load_data():
    df = pd.read_csv("../Datos/Datos OCDE.csv")
    df = df[['REF_AREA', 'SEX', 'TIME_PERIOD', 'OBS_VALUE', 'MEASURE']]
    df = df[df['MEASURE'] == 'LFEXP']
    df['OBS_VALUE'] = pd.to_numeric(df['OBS_VALUE'], errors='coerce')
    df['SEX'] = df['SEX'].map({'F': 'Femenino', 'M': 'Masculino', '_T': 'Total'})
    
    ocde_countries = [
        'AUS', 'AUT', 'BEL', 'CAN', 'CHL', 'COL', 'CZE', 'DNK', 'EST', 'FIN',
        'FRA', 'DEU', 'GRC', 'HUN', 'ISL', 'IRL', 'ISR', 'ITA', 'JPN', 'KOR',
        'LVA', 'LTU', 'LUX', 'MEX', 'NLD', 'NZL', 'NOR', 'POL', 'PRT', 'SVK',
        'SVN', 'ESP', 'SWE', 'CHE', 'TUR', 'GBR', 'USA'
    ]
    df['OCDE'] = df['REF_AREA'].apply(lambda x: 'Sí' if x in ocde_countries else 'No')
    return df

# Cargar datos
df = load_data()

# Título de la página
st.title("📊 Resumen Estadístico de la Esperanza de Vida")
st.markdown("""
Aqui se puede ver el promedio, desviacion estandar, el valor minimo y maximo de la esperanza de vida por año y por pertenencia a la OCDE
""")

# Selección de año
años_disponibles = sorted(df["TIME_PERIOD"].unique(), reverse=True)
año_seleccionado = st.radio("Selecciona el año de análisis:", años_disponibles, index=0)

# Opción para desagrupar por OCDE
desagrupar_ocde = st.checkbox("Desagrupar por pertenencia a la OCDE")

if desagrupar_ocde:
    df_ocde = df[(df["TIME_PERIOD"] == año_seleccionado) & (df["OCDE"] == "Sí")]
    df_no_ocde = df[(df["TIME_PERIOD"] == año_seleccionado) & (df["OCDE"] == "No")]

    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🌍 Países OCDE")
        st.metric("Promedio", f"{df_ocde['OBS_VALUE'].mean():.2f} años")
        st.metric("Desviación estándar", f"{df_ocde['OBS_VALUE'].std():.2f}")
        st.metric("Mínimo", f"{df_ocde['OBS_VALUE'].min():.2f}")
        st.metric("Máximo", f"{df_ocde['OBS_VALUE'].max():.2f}")

    with col2:
        st.subheader("🌎 Países No OCDE")
        st.metric("Promedio", f"{df_no_ocde['OBS_VALUE'].mean():.2f} años")
        st.metric("Desviación estándar", f"{df_no_ocde['OBS_VALUE'].std():.2f}")
        st.metric("Mínimo", f"{df_no_ocde['OBS_VALUE'].min():.2f}")
        st.metric("Máximo", f"{df_no_ocde['OBS_VALUE'].max():.2f}")

else:
    df_filtrado = df[df["TIME_PERIOD"] == año_seleccionado]
    st.metric("Promedio", f"{df_filtrado['OBS_VALUE'].mean():.2f} años")
    st.metric("Desviación estándar", f"{df_filtrado['OBS_VALUE'].std():.2f}")
    st.metric("Mínimo", f"{df_filtrado['OBS_VALUE'].min():.2f}")
    st.metric("Máximo", f"{df_filtrado['OBS_VALUE'].max():.2f}")

col1, col2, col3 = st.columns([1,2,1])  # Más espacio a la izquierda
with col3:
    st.page_link("Evo.py", label="Pagina siguiente", icon="🔜")
with col1:
    st.page_link("Main.py", label="Pagina anterior", icon="🔙")