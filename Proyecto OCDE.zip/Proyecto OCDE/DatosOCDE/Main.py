import streamlit as st

st.title("📊 Análisis de Esperanza de Vida")
st.markdown("""
Este es un analisis interactivo de la esperanza de vida de diversos paises a lo largo de los años donde se puede encontrar:
- Visualizacion de un resumen de los datos
- Comparaciones de la distribución de la esperanza de vida por género o pertenencia a la OCDE.
- Ver la evolución temporal de la esperanza de vida en diferentes países.

Todo esto sacado de la pagina oficial de la  Organización para la Cooperación y el Desarrollo Económicos (OCDE) tomando variables como:
- OBS_VALUE para la esperanza de vida
- REF_AREA para ver los casi 50 paises representados con sus tres primeras letras 
- SEX para el genero
-TIME_PERIOD para los años cubiertos desde 2015 hasta 2023
            
Ademas de una variable externa llamada OCDE para la comparacion de pertenencia a la OCDE o no.
""")

col1, col2, col3 = st.columns([1,2,1])  # Más espacio a la izquierda
with col3:
    st.page_link("Resum.py", label="Pagina siguiente", icon="🔜")