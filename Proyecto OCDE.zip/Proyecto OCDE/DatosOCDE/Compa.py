import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Cargar datos directamente en esta página
@st.cache_data
def load_data():
    df = pd.read_csv("../Datos/Datos OCDE.csv")
    df = df[['REF_AREA', 'SEX', 'TIME_PERIOD', 'OBS_VALUE', 'MEASURE']]
    df = df[df['MEASURE'] == 'LFEXP']
    df['OBS_VALUE'] = pd.to_numeric(df['OBS_VALUE'], errors='coerce')
    df['SEX'] = df['SEX'].map({'F': 'Femenino', 'M': 'Masculino', '_T': 'Total'})
    ocde_countries = [
        'AUS', 'AUT', 'BEL', 'CAN', 'CHL', 'COL', 'CZE', 'DNK', 'EST', 'FIN',
        'FRA', 'DEU', 'GRC', 'HUN', 'ISL', 'IRL', 'ISR', 'ITA', 'JPN', 'KOR',
        'LVA', 'LTU', 'LUX', 'MEX', 'NLD', 'NZL', 'NOR', 'POL', 'PRT', 'SVK',
        'SVN', 'ESP', 'SWE', 'CHE', 'TUR', 'GBR', 'USA'
    ]
    df['OCDE'] = df['REF_AREA'].apply(lambda x: 'Sí' if x in ocde_countries else 'No')
    return df

df = load_data()

# Título y selección de año
st.title("📊 Comparación de Distribución de Esperanza de Vida")
st.markdown("""
En esta grafica se puede apreciar una comparativa entre la distribucion por año y genero o por pertenencia a la OCDE.
""")
años_disponibles = sorted(df["TIME_PERIOD"].unique(), reverse=True)
año_seleccionado = st.radio("Selecciona el año:", años_disponibles, index=0)

# Opción de comparación
opcion_comparacion = st.radio("¿Qué deseas comparar?", ["Género", "Pertenencia a la OCDE"])

plt.figure(figsize=(8, 5))
df_filtrado = df[df["TIME_PERIOD"] == año_seleccionado]

if opcion_comparacion == "Género":
    sns.boxplot(x="SEX", y="OBS_VALUE", data=df_filtrado)
    plt.title("Distribución de Esperanza de Vida por Género")
else:
    sns.boxplot(x="OCDE", y="OBS_VALUE", data=df_filtrado)
    plt.title("Distribución de Esperanza de Vida por Membresía OCDE")

st.pyplot(plt)

col1, col2, col3 = st.columns([1,2,1])  # Más espacio a la izquierda
with col3:
    st.page_link("Bar.py", label="Pagina siguiente", icon="🔜")
with col1:
    st.page_link("Evo.py", label="Pagina anterior", icon="🔙")
