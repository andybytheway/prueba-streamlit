import streamlit as st

pages = {
    "Datos y visualizacion": [
        st.Page("Main.py", title="Introduccion"),
        st.Page("Resum.py", title="Resumen visualizado"),
    ],
    "Graficas": [
        st.Page("Evo.py", title="Evolucion de esperanza de vida"),
        st.Page("Compa.py", title="Comparacion de distribucion"),
        st.Page("Bar.py", title="Grafica de barras"),
    ],
}

pg = st.navigation(pages)
pg.run()