import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Cargar datos directamente en esta página
@st.cache_data
def load_data():
    df = pd.read_csv("../Datos/Datos OCDE.csv")
    df = df[['REF_AREA', 'SEX', 'TIME_PERIOD', 'OBS_VALUE', 'MEASURE']]
    df = df[df['MEASURE'] == 'LFEXP']
    df['OBS_VALUE'] = pd.to_numeric(df['OBS_VALUE'], errors='coerce')
    df['SEX'] = df['SEX'].map({'F': 'Femenino', 'M': 'Masculino', '_T': 'Total'})
    ocde_countries = [
        'AUS', 'AUT', 'BEL', 'CAN', 'CHL', 'COL', 'CZE', 'DNK', 'EST', 'FIN',
        'FRA', 'DEU', 'GRC', 'HUN', 'ISL', 'IRL', 'ISR', 'ITA', 'JPN', 'KOR',
        'LVA', 'LTU', 'LUX', 'MEX', 'NLD', 'NZL', 'NOR', 'POL', 'PRT', 'SVK',
        'SVN', 'ESP', 'SWE', 'CHE', 'TUR', 'GBR', 'USA'
    ]
    df['OCDE'] = df['REF_AREA'].apply(lambda x: 'Sí' if x in ocde_countries else 'No')
    return df

df = load_data()

# Título y selección de países
st.title("📈 Evolución de la Esperanza de Vida")
st.markdown("""
En esta grafica se puede apreciar la evolucion de la esperanza de vida ya sea de manera general o por genero especifico.
""")
paises_disponibles = df["REF_AREA"].unique()
paises_seleccionados = st.multiselect("Selecciona países:", paises_disponibles)

if paises_seleccionados:
    df_paises = df[df["REF_AREA"].isin(paises_seleccionados)]
    desagrupar_genero = st.checkbox("Desagrupar por género")

    plt.figure(figsize=(10, 5))

    if desagrupar_genero:
        sns.lineplot(data=df_paises, x="TIME_PERIOD", y="OBS_VALUE", hue="SEX", style="REF_AREA", markers=True)
        plt.title("Evolución de la Esperanza de Vida por Género")
    else:
        df_paises_total = df_paises[df_paises['SEX'] == 'Total']
        sns.lineplot(data=df_paises_total, x="TIME_PERIOD", y="OBS_VALUE", hue="REF_AREA", markers=True)
        plt.title("Evolución de la Esperanza de Vida (Total)")

    plt.xlabel("Año")
    plt.ylabel("Esperanza de Vida")
    st.pyplot(plt)

col1, col2, col3 = st.columns([1,2,1])  # Más espacio a la izquierda
with col3:
    st.page_link("Compa.py", label="Pagina siguiente", icon="🔜")
with col1:
    st.page_link("Resum.py", label="Pagina anterior", icon="🔙")