import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Cargar los datos directamente en esta página
@st.cache_data
def load_data():
    df = pd.read_csv("..\Datos\Datos OCDE.csv")
    df = df[['REF_AREA', 'SEX', 'TIME_PERIOD', 'OBS_VALUE', 'MEASURE']]
    df = df[df['MEASURE'] == 'LFEXP']
    df['OBS_VALUE'] = pd.to_numeric(df['OBS_VALUE'], errors='coerce')
    df['SEX'] = df['SEX'].map({'F': 'Femenino', 'M': 'Masculino', '_T': 'Total'})

    # Agregar columna para membresía a la OCDE
    ocde_countries = [
        'AUS', 'AUT', 'BEL', 'CAN', 'CHL', 'COL', 'CZE', 'DNK', 'EST', 'FIN',
        'FRA', 'DEU', 'GRC', 'HUN', 'ISL', 'IRL', 'ISR', 'ITA', 'JPN', 'KOR',
        'LVA', 'LTU', 'LUX', 'MEX', 'NLD', 'NZL', 'NOR', 'POL', 'PRT', 'SVK',
        'SVN', 'ESP', 'SWE', 'CHE', 'TUR', 'GBR', 'USA'
    ]
    df['OCDE'] = df['REF_AREA'].apply(lambda x: 'Sí' if x in ocde_countries else 'No')
    return df

# Cargar datos
df = load_data()

# Título de la página
st.title("📊 Comparación General de Esperanza de Vida (País, Género y OCDE)")

# Seleccionar año
años_disponibles = sorted(df["TIME_PERIOD"].unique(), reverse=True)
año_seleccionado = st.radio("Selecciona el año para la comparación:", años_disponibles, index=0)

# Filtro por año seleccionado
df_año = df[df["TIME_PERIOD"] == año_seleccionado]

# Opciones para filtrar género y membresía OCDE
generos_seleccionados = st.multiselect("Selecciona los géneros para comparar:", ['Femenino', 'Masculino', 'Total'], default=['Femenino', 'Masculino'])
ocde_seleccion = st.radio("¿Deseas comparar países por membresía a la OCDE?", ['Todos', 'Solo OCDE', 'Solo No OCDE'], index=0)

# Aplicar filtros seleccionados
if generos_seleccionados:
    df_año = df_año[df_año['SEX'].isin(generos_seleccionados)]

if ocde_seleccion == 'Solo OCDE':
    df_año = df_año[df_año['OCDE'] == 'Sí']
elif ocde_seleccion == 'Solo No OCDE':
    df_año = df_año[df_año['OCDE'] == 'No']

# Gráfica de barras combinada (País, Género y OCDE)
st.subheader(f"Esperanza de Vida por País, Género y OCDE en {año_seleccionado}")

plt.figure(figsize=(15, 8))
sns.barplot(data=df_año, x='REF_AREA', y='OBS_VALUE', hue='SEX')

plt.xlabel("País")
plt.ylabel("Esperanza de Vida (años)")
plt.title(f"Esperanza de Vida por País y Género en {año_seleccionado}")
plt.xticks(rotation=90)
plt.legend(title="Género")

st.pyplot(plt)

col1, col2, col3 = st.columns([1,2,1])  # Más espacio a la izquierda
with col1:
    st.page_link("Compa.py", label="Pagina anterior", icon="🔙")